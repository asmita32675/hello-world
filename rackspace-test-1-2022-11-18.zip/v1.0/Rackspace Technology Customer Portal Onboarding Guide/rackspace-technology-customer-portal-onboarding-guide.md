---
title: "Rackspace Technology Customer Portal Onboarding Guide"
slug: "rackspace-technology-customer-portal-onboarding-guide"
hidden: false
createdAt: "2022-11-15T08:29:36.708Z"
updatedAt: "2022-11-18T08:18:48.076Z"
---
This user guide provides an introduction to the Rackspace Technology Customer Portal. The following sections include details about common tasks that you can perform using this portal.

The following sections provide information about the Customer Portal.

# Intended Audience

This guide is intended for new Rackspace Technology customers who use the Rackspace Technology Customer Portal to manage their account. Some solutions, like Object Rocket and Onica, have their own portals and do not require access to The Rackspace Technology Customer Portal. For more information about these solutions, refer to the relevant documentation on the Rackspace Technology Support site.

# Log in to the Rackspace Technology Customer Portal

When you become a Rackspace Technology customer, we provide you with access to customer portals for managing your cloud accounts. These portals are different for Public Cloud and Private Cloud customers.

## The Account Registration Code

Rackspace Technology uses an account registration code to verify new users. When an account administrator adds you as a user, you receive an email with your account registration code and instructions on how to log in to the Rackspace Technology Customer Portal for the first time. You need this registration code only during your first login or if you forget your username.

The primary contact on the account is the only person who can change this code. When the primary contact adds a user, the user receives a registration code.

If you are the primary contact on the account and you forget the code or need to reset your login, contact your account manager or Rackspace Technology Support.

## The Global Navigation Menu

Although the Rackspace Technology customer portal is different for Public Cloud and Private Cloud customers, both portals include a global navigation menu that allows you to complete common tasks easily.

To access the global navigation menu:

1. Log in to the Rackspace Technology Customer Portal.
2. Select from the global navigation dropdown menu items.

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/b649855-global_nav.png",
        null,
        ""
      ],
      "border": true
    }
  ]
}
[/block]



# Account Dashboard

The account dashboard displays all your Rackspace Technology accounts in a single view.

To view the account dashboard:

1. Log in to the Rackspace Technology Customer Portal.
2. Click the Select a Product drop-down option in the upper-left corner.

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/a375d5c-my_account.png",
        null,
        ""
      ],
      "border": true
    }
  ]
}
[/block]



Select My Accounts. The account dashboard displays.

- Use the search bar or select the funnel icon to search or filter available accounts.
- Select an account to display additional details, if available.

![](https://files.readme.io/6101d57-solutions_dashboard.png)

# Manage Your Portal Profiles

To view and edit your profile settings and the [notifications ](https://docs.rackspace.com/docs/portal-onboarding-guide/notifications/#notifications)for your account, select your username from the global navigation menu.

Select My Profile & Settings to view your primary contact information, view or edit your security settings, and view your account and product permissions.

This display is different for Private cloud and Public cloud customers.

## Private Cloud

If you are a [Private Cloud](https://www.rackspace.com/cloud/private?_ga=2.255266378.39487042.1668412243-429163457.1658160663&_gl=1*ujeqra*_ga*NDI5MTYzNDU3LjE2NTgxNjA2NjM.*_ga_P5J3XFCZLB*MTY2ODc1OTM3Ny4yMTguMS4xNjY4NzU5NDQzLjAuMC4w) customer, the following information displays:

| Section                    | Description                                                                                                                                                           |
| :------------------------- | :-------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Ticket Email Notifications | Update your name and contact information                                                                                                                              |
| API Access                 | [Manage your API key](https://docs.rackspace.com/docs/portal-onboarding-guide/manage_portal_user_groups/api_key#api-key) for authenticating Rackspace Technology APIs |
| User Information           | Update your contact information, support PIN, and password                                                                                                            |
| Support PIN                | A Support PIN is the customer secret that the customer uses to verify their identity when they call in for technical, billing, or account management support          |
| Update Password            | Update your password or registration code                                                                                                                             |

## Public Cloud

If you are a [Public Cloud](https://www.rackspace.com/cloud/public?_gl=1*1kcoa0l*_ga*NDI5MTYzNDU3LjE2NTgxNjA2NjM.*_ga_P5J3XFCZLB*MTY2ODY5ODc0OC4yMTYuMS4xNjY4Njk4NzU1LjAuMC4w&_ga=2.188557674.39487042.1668412243-429163457.1658160663) customer, the following information displays:

| Section                       | Description                                                                                                                                                                                       |
| :---------------------------- | :------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| Primary Contact Information   | Displays the contact information for your entire Rackspace Cloud solutions account. Review change_account_name for more information                                                               |
| Security Settings             | [Manage your API key](https://docs.rackspace.com/docs/portal-onboarding-guide/manage_portal_user_groups/api_key#api-key) for authenticating Rackspace Technology APIs                             |
| User Information              | Change your password, enable or disable multi-factor authentication, and [Manage your API key](https://docs.rackspace.com/docs/portal-onboarding-guide/manage_portal_user_groups/api_key#api-key) |
| Rackspace Account Permissions | View your account permissions.                                                                                                                                                                    |
| Product Permission            | View the products associated with your account                                                                                                                                                    |