---
title: "Account Management"
slug: "account-management"
excerpt: "Managing your account includes actions such as updating contact information, changing account owners or company names, managing users on your account, managing invoices, and more."
hidden: false
createdAt: "2022-11-18T09:08:51.233Z"
updatedAt: "2022-11-18T09:09:57.072Z"
---
Account Management

- Change your Account Company Name
- Change account information
- Change your Cloud Account Owner
- Update your Account’s Primary Contact
- Sign up for Rackspace services